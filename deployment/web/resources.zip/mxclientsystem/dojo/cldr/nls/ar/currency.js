/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ar/currency",{HKD_displayName:"\u062f\u0648\u0644\u0627\u0631 \u0647\u0648\u0646\u062c \u0643\u0648\u0646\u062c",CHF_displayName:"\u0641\u0631\u0646\u0643 \u0633\u0648\u064a\u0633\u0631\u064a",JPY_symbol:"JP\u00a5",CAD_displayName:"\u062f\u0648\u0644\u0627\u0631 \u0643\u0646\u062f\u064a",HKD_symbol:"HK$",CNY_displayName:"\u064a\u0648\u0627\u0646 \u0635\u064a\u0646\u064a",USD_symbol:"US$",AUD_displayName:"\u062f\u0648\u0644\u0627\u0631 \u0623\u0633\u062a\u0631\u0627\u0644\u064a",
JPY_displayName:"\u064a\u0646 \u064a\u0627\u0628\u0627\u0646\u064a",CAD_symbol:"CA$",USD_displayName:"\u062f\u0648\u0644\u0627\u0631 \u0623\u0645\u0631\u064a\u0643\u064a",EUR_symbol:"\u20ac",CNY_symbol:"\u064a.\u0635",GBP_displayName:"\u062c\u0646\u064a\u0647 \u0625\u0633\u062a\u0631\u0644\u064a\u0646\u064a",GBP_symbol:"\u00a3",AUD_symbol:"AU$",EUR_displayName:"\u064a\u0648\u0631\u0648"});
