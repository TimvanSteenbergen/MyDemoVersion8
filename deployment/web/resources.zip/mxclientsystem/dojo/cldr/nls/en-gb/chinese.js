/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-gb/chinese",{"dateFormat-medium":"d MMM U","dateFormatItem-yMd":"dd/MM/y","dateFormatItem-MMMEd":"E d MMM","dateFormatItem-MEd":"E dd/MM","months-format-narrow":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"dateTimeFormat-medium":"{1} {0}","dateFormatItem-GyMMMd":"d MMM U","dateFormatItem-Md":"dd/MM","months-standAlone-narrow":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"months-standAlone-wide":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"dateFormatItem-GyMMMEd":"E, d MMM U","dateFormatItem-M":"LL",
"dateFormatItem-yyyyMMMEd":"E, d MMM U","dateFormatItem-yyyyMEd":"E, dd/MM/y","dateFormatItem-yyyyMMMM":"MMMM U","dateFormatItem-MMMMd":"d MMMM","dateTimeFormat-long":"{1} {0}","months-standAlone-abbr":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"dateFormat-long":"d MMMM U","field-dayperiod":"am/pm","dateFormat-short":"dd/MM/yy","dateTimeFormat-short":"{1} {0}","months-format-wide":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),"dateTimeFormat-full":"{1} {0}","months-format-abbr":"1 2 3 4 5 6 7 8 9 10 11 12".split(" "),
"dateFormatItem-yyyyMMMd":"d MMM U","dateFormatItem-yyyyM":"MM/y","dateFormat-full":"EEEE, d MMMM U","dateFormatItem-MMMd":"d MMM","dateFormatItem-yyyyMd":"dd/MM/y","dateFormatItem-Ed":"E d"});
