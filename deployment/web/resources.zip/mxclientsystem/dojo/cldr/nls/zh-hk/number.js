/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/zh-hk/number",{$locale:"zh-hant-hk","decimalFormat-short":"000T",nan:"\u975e\u6578\u503c"});
